﻿
namespace Lab2_3
{
    public class Program
    {
        public static void Main()
        {
            Console.WriteLine("Enter serial code for document worker");
            string? key = Console.ReadLine();
            Console.WriteLine("Key accepted");
            DocumentWorker worker;
            switch (key)
            {
                case "pro":
                    Console.WriteLine("Created pro document worker");
                    worker = new ProDocumentWorker();
                break;
                case "expert":
                    Console.WriteLine("Created expert document worker");
                    worker = new ExpertDocumentWorker();
                break;
                default:
                    Console.WriteLine("Created free document worker");
                    worker = new DocumentWorker();
                break;
            }
            worker.OpenDocument();
            worker.EditDocument();
            worker.SaveDocument();
        }
    }
}