﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_1
{
    class ClassRoom
    {
        private Pupil[] pupils;

        public ClassRoom(params Pupil[] list)
        {
            pupils = list;
        }

        public void PrintClassRoom()
        {
            for(int i = 0; i < pupils.Length; i++)
            {
                Pupil p = pupils[i];
                Console.WriteLine("Pupil " + i.ToString());
                p.Study();
                p.Read();
                p.Write();
                p.Relax();
                Console.WriteLine();
            }
        }
    }


}
