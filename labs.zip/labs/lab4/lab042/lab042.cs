﻿using System;

class Car
{
    private string name;
    private int productionYear;
    private int maxSpeed;

    public string Name2 { get; set; }

    public string Name
    {
        get { return name; }
        set { name = value; }
    }

    public int ProductionYear
    {
        get { return productionYear; }
        set { productionYear = value; }
    }

    public int MaxSpeed
    {
        get { return maxSpeed; }
        set { maxSpeed = value; }
    }

    public Car(string name, int productionYear, int maxSpeed)
    {
        Name = name;
        ProductionYear = productionYear;
        MaxSpeed = maxSpeed;
    }
}
class CarComparer : IComparer<Car>
{
    private string sortBy;

    public CarComparer(string sortBy)
    {
        this.sortBy = sortBy;
    }

    public int Compare(Car x, Car y)
    {
        switch (sortBy)
        {
            case "Name":
                return x.Name.CompareTo(y.Name);
            case "ProductionYear":
                return x.ProductionYear.CompareTo(y.ProductionYear);
            case "MaxSpeed":
                return x.MaxSpeed.CompareTo(y.MaxSpeed);
            default:
                return 0;
        }
    }
}

class lab042
{
    static void Main()
    {
        Car[] cars = new Car[]
        {
            new Car("Lada Granda", 2015, 150),
            new Car("Lada Sport", 2023, 2000),
            new Car("Zaporozhec", 1977, 500),
            new Car("YAZ", 1980, 8934)
        };

        Console.WriteLine("\nCars:");
        foreach (var car in cars)
        {
            Console.WriteLine($"{car.Name}, {car.ProductionYear}, {car.MaxSpeed}");
        }

        bool end = false;  
        while (!end)
        {
            end = true;
            Console.WriteLine("\nChoose the type of sort):");
            string type = Console.ReadLine();
            switch (type)
            {
                case "Name":
                    Console.WriteLine("Sorted by name");
                    Array.Sort(cars, new CarComparer("Name"));
                    break;
                case "Year":
                    Console.WriteLine("Sorted by year");
                    Array.Sort(cars, new CarComparer("Year"));
                    break;
                case "Speed":
                    Console.WriteLine("Sorted by speed");
                    Array.Sort(cars, new CarComparer("Speed"));
                    break;
                default:
                    Console.WriteLine("There is no such sort type");
                    end = false;
                    break;
            }
        }

        Console.WriteLine("\nSorted cars:");
        foreach (var car in cars)
        {
            Console.WriteLine($"{car.Name}, {car.ProductionYear}, {car.MaxSpeed}");
        }
    }
}
